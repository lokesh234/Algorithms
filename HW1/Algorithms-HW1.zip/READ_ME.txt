To run the program use the following command:

hw1.exe [p1] [p2]

where [p1] and [p2] are optional posistional arguments that determine how 
each player 1 and player 2 are controlled.  The following values may be used:

    human - The player's moves are determined by a human via the command prompt input
    random - The player plays randomly.
    win - The player will play the winning strategy if possible.  If not, it will play randomly

If they are not specified the default for [p1] is "human" and the default for [p2] is "win".


