To run the program use the following command:

hw1.exe [humanFirst]

where [humanFirst] is an optional argument (default is true) that determines 
if the human player goes before the CPU.
