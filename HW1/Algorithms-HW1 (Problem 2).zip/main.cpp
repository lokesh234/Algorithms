#include "main.h"

void printBoard(int board[3])
{
    std::cout << "\nGreen: " << board[0] << "\nOrange: " << board[1] << "\nYellow: " << board[2] << std::endl;
}

int *choose(int board[3])
{
    int *move = new int[2];
    std::string color;
    std::cout << "Your Move: ";
    std::cin >> color;   // Color to take
    std::cin >> move[1]; // Number to take
    std::transform(color.begin(), color.end(), color.begin(), ::tolower);

    bool valid = true;
    if (color == "green")
    {
        move[0] = GREEN;
    }
    else if (color == "orange")
    {
        move[0] = ORANGE;
    }
    else if (color == "yellow")
    {
        move[0] = YELLOW;
    }
    else
    {
        valid = false;
        std::cout << "You misspelled or misformatted something!  Use the format \"color #\"" << std::endl;
    }
    if (valid && board[move[0]] < move[1])
    {
        valid = false;
        std::cout << "There aren't that many for you to take!  Pick another color or take fewer of them." << std::endl;
    }

    if (!valid)
    {
        move = choose(board);
    }
    return move;
}

int *chooseCPU(int board[3])
{
    int *move = new int[2];
    int color;
    do
    {
        color = rand() % 3;
    } while (board[color] == 0); // Pick green, orange, or yellow randomly.
    move[0] = color;
    move[1] = rand() % board[color] + 1;

    std::cout << "CPU's Move: " << (move[0] == 0 ? "Green " : (move[0] == 1 ? "Orange " : "Yellow ")) << move[1] << std::endl;

    return move;
}

void move(int board[3], int move[2])
{
    board[move[0]] -= move[1];
}

int main(int argc, char *argv[])
{
    int turn = 1;
    int board[3] = {3, 5, 7}; // In order of green, orange, yellow
    bool humanTurn = true;
    bool boardEmpty = false;

    // If human turn is first
    if (argc >= 2 && strcmp(argv[1], "false") == 0)
    {
        humanTurn = false;
    }
    std::cout << "Enter moves in the format [input \"color #\"]\nFirst turn: " << (humanTurn ? "you" : "CPU") << std::endl;

    while (!boardEmpty)
    {
        printBoard(board);
        if (humanTurn)
        {
            move(board, choose(board));
        }
        else
        {
            move(board, chooseCPU(board));
        }
        if (board[0] == 0 && board[1] == 0 && board[2] == 0)
        {
            boardEmpty = true;
        }
        else
        {
            humanTurn = !humanTurn;
        }
    }
    std::cout << (humanTurn ? "You win!" : "CPU wins!") << std::endl;
    return 0;
}
